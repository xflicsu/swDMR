capture <- function( expression, collapse="\n")
    .Defunct("capture.output", "base")

sprint <- function(x,...)
    .Defunct("capture.output", "base")

