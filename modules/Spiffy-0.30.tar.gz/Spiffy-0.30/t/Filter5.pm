package Filter5;
use Spiffy -Base;
my sub xxx {
    $self->$xxx;
    $self->$yyy;
}
my sub yyy {
    $self->$xxx;
    $self->$yyy
}
